@extends('layouts.mainLayout')

@section('sectionX')

<div class="profile-settings-section">
    <h2>Profile Settings</h2>

    <!-- Update Profile Form -->
    <form method="post" action="">
        <label for="bio">Bio:</label>
        <textarea name="bio"></textarea>

        <label for="email">Email:</label>
        <input type="email" name="email" ">
        
        <label for="contact">Contact No:</label>
        <input type="number" name="contact" ">

        <label for="address">Address:</label>
        <input type="text" name="address" ">
        <!-- Add more fields for other profile settings -->

        <button type="submit" name="update_profile">Update Profile</button>
    </form>

    <!-- Delete Account Form -->
    <form method="post" action="">
        <p>Deleting your account is irreversible. Are you sure you want to proceed?</p>
        <button type="submit" name="delete_account">Delete Account</button>
    </form>
</div>
@endsection